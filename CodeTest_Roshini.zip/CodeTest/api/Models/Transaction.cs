﻿using System;

namespace api.Models
{
    public class Transaction
    {
        public DateTime Date { get; set; }
        public decimal Balance { get; set; }
    }
}