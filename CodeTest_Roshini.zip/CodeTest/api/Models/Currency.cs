﻿namespace api.Models
{
    public class Currency
    {
        public string Name { get; set; }
        public decimal ExchangeRate { get; set; }
    }
}