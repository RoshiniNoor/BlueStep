﻿using api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

namespace api.Services
{
    public class ExchangeRateService : IExchangeRateService
    {
        public async Task<ExchangeRate> GetExchangeRate()
        {
            string getExchangeRateUrl = "https://bstpdevelopertestfiles.z16.web.core.windows.net/currencies.json";

            using HttpClient client = new HttpClient();
            HttpResponseMessage response = await client.GetAsync(getExchangeRateUrl);

            if (response.IsSuccessStatusCode)
            {
                string json = await response.Content.ReadAsStringAsync();
                ExchangeRate exchangeRate = Newtonsoft.Json.JsonConvert.DeserializeObject<ExchangeRate>(json);
                return exchangeRate;
            }
            else
            {
                throw new Exception($"Failed to retrieve exchangeRate. Status code: {response.StatusCode}");
            }
        }
    }
}
