﻿using api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

namespace api.Services
{
    public class AccountService : IAccountService
    {
        public async Task<Account> GetAccount()
        {
            string getAccountInfoUrl = "https://bstpdevelopertestfiles.z16.web.core.windows.net/account.json";

            using HttpClient client = new HttpClient();
            HttpResponseMessage response = await client.GetAsync(getAccountInfoUrl);

            if (response.IsSuccessStatusCode)
            {
                string json = await response.Content.ReadAsStringAsync();
                Account account = Newtonsoft.Json.JsonConvert.DeserializeObject<Account>(json);
                return account;
            }
            else
            {
                throw new Exception($"Failed to retrieve account. Status code: {response.StatusCode}");
            }
        }
    }
}
