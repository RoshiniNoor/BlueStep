﻿using api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace api.Services
{
    public class ConversionService : IConversionService
    {
        private readonly IAccountService _accountService;
        private readonly IExchangeRateService _exchangeRateService;

        public ConversionService(IAccountService accountService, IExchangeRateService exchangeRateService)
        {
            _accountService = accountService;
            _exchangeRateService = exchangeRateService;
        }
        public async Task<Account> GetConvertedAccount(string currency)
        {
            Account actualAccount = await _accountService.GetAccount();
            ExchangeRate exchangeRate = await _exchangeRateService.GetExchangeRate();
            Currency targetCurrency = exchangeRate.Currencies.FirstOrDefault(c => c.Name.Equals(currency));

            if (targetCurrency != null)
            {
                Account account = new Account
                {
                    AccountNumber = actualAccount.AccountNumber,
                    Balance = actualAccount.Balance * targetCurrency.ExchangeRate,
                    Currency = currency
                };

                return account;
            }

            throw new ArgumentException("NOT_VALID");
        }
    }
}
